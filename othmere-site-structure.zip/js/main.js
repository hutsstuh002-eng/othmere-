// Othmere global JavaScript.
